//
//  MainPageRankingCollectionViewCell.swift
//  ZZin
//
//  Created by clone1 on 2023/10/15.
//

import UIKit

class MainPageRankingCollectionViewCell: UICollectionViewCell {
    
//    static let identifier = "MainPageCollectionViewCell"
//    private var isBookmarked = false
//
//    private let view: UIView = {
//        let view = UIView()
//        view.backgroundColor = .white
//        view.layer.cornerRadius = 16
//        view.clipsToBounds = true
//        return view
//    }()
//
//    var picture: UIImageView = {
//        let imageView = UIImageView()
//        imageView.image = UIImage(systemName: "photo")
//        imageView.contentMode = .scaleAspectFill
//        imageView.clipsToBounds = true
//        imageView.snp.makeConstraints { make in
//            make.height.equalTo(118)
//        }
//        return imageView
//    }()
//
//    let title: UILabel = {
//        let label = UILabel()
//        label.text = "0"
//        label.textAlignment = .left
//        label.font = FontGuide.size14Bold
//        label.textColor = .white
//        label.snp.makeConstraints { make in
//            make.height.equalTo(20)
//        }
//        return label
//    }()
//}
//
//extension MainPageRankingCollectionViewCell {
//    func setupUI() {
//
//        view.addSubview(picture)
//        picture.snp.makeConstraints { make in
//            make.top.leading.trailing.equalToSuperview()
//            make.height.equalToSuperview()
//        }
//
//        view.addSubview(title)
//        title.snp.makeConstraints { make in
//            make.top.equalTo(picture.snp.top).offset(12)
//            make.leading.equalToSuperview().offset(12)
//        }
//    }
}
